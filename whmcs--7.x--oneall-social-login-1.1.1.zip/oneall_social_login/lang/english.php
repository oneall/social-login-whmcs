<?php
$_ADDONLANG['oneall_link_account'] = 'Link External Account';
$_ADDONLANG['oneall_link_button'] = 'Link Account';
$_ADDONLANG['oneall_link_incorrect'] = 'Existing account details incorrect, please try again.';
$_ADDONLANG['oneall_link_success'] = 'Your existing account has been linked!  <a href="./clientarea.php">Continue to your client area.</a>';
$_ADDONLANG['oneall_email_address'] = 'Email Address';
$_ADDONLANG['oneall_password'] = 'Password';
$_ADDONLANG['oneall_link_intro1'] = 'This is the first time you have logged in using your account:';
$_ADDONLANG['oneall_link_intro2'] = '
You may optionally link this external account to an existing account you have with us.  To do so simply fill in the
log in form below and click the "Link Account" button.  If you do not have an existing account you may <a href="./clientarea.php">continue to your client area</a>';

?>