# Change Log

All notable changes to this project will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org/).

## [2.0.0] - 2022-04-22
### Fixed
Fix non working login for WHMCS 8+
### Added
New providers added :
- Epic Games
- Spotify
- Strava
- Yandex